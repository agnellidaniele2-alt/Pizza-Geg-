// Storage helpers
const LS_MENU_KEY = "pg_menu";
const LS_ORDER_KEY = "pg_order";

const config = window.PIZZA_GEGE_CONFIG;

// Elements
const publicView = document.getElementById('publicView');
const internalView = document.getElementById('internalView');
const menuList = document.getElementById('menuList');
const searchInput = document.getElementById('search');
const lockBtn = document.getElementById('lockBtn');

const adminMenuList = document.getElementById('adminMenuList');
const dishName = document.getElementById('dishName');
const dishPrice = document.getElementById('dishPrice');
const dishDesc = document.getElementById('dishDesc');
const saveDish = document.getElementById('saveDish');
const clearForm = document.getElementById('clearForm');

const orderDishSelect = document.getElementById('orderDishSelect');
const orderQty = document.getElementById('orderQty');
const orderNote = document.getElementById('orderNote');
const addToOrderBtn = document.getElementById('addToOrder');
const orderList = document.getElementById('orderList');
const orderTotal = document.getElementById('orderTotal');
const receiptArea = document.getElementById('receiptArea');
const printBtn = document.getElementById('printBtn');
const clearOrderBtn = document.getElementById('clearOrder');

const pinModal = document.getElementById('pinModal');
const pinInput = document.getElementById('pinInput');
const pinOk = document.getElementById('pinOk');
const pinCancel = document.getElementById('pinCancel');

// State
let menu = JSON.parse(localStorage.getItem(LS_MENU_KEY) || "[]");
let order = JSON.parse(localStorage.getItem(LS_ORDER_KEY) || "[]");
let editingId = null;

// Helpers
function fmt(n){ return config.currency + (n).toFixed(2).replace('.', ','); }

function saveMenu(){ localStorage.setItem(LS_MENU_KEY, JSON.stringify(menu)); renderPublic(); renderAdmin(); renderDishSelect(); }
function saveOrder(){ localStorage.setItem(LS_ORDER_KEY, JSON.stringify(order)); renderOrder(); renderReceipt(); }

function renderPublic(){
  const q = (searchInput.value||"").toLowerCase();
  menuList.innerHTML = "";
  menu.filter(d => d.name.toLowerCase().includes(q) || (d.description||"").toLowerCase().includes(q)).forEach(d => {
    const li = document.createElement('li');
    li.innerHTML = `<div><div class="title"><strong>${d.name}</strong></div>
                    <div class="desc">${d.description||''}</div></div>
                    <div class="price">${fmt(d.price)}</div>`;
    menuList.appendChild(li);
  });
}

function renderAdmin(){
  adminMenuList.innerHTML = "";
  menu.forEach((d, idx) => {
    const li = document.createElement('li');
    const left = document.createElement('div');
    left.style.flex = "1";
    left.innerHTML = `<strong>${d.name}</strong><br><small>${d.description||''}</small>`;
    const right = document.createElement('div');
    right.innerHTML = `<div style="text-align:right">${fmt(d.price)}</div>
      <div class="row" style="margin-top:6px">
        <button data-edit="${idx}">Modifica</button>
        <button class="danger" data-del="${idx}">Elimina</button>
      </div>`;
    li.appendChild(left); li.appendChild(right);
    adminMenuList.appendChild(li);
  });
}

function renderDishSelect(){
  orderDishSelect.innerHTML = "";
  menu.forEach((d, idx) => {
    const opt = document.createElement('option');
    opt.value = idx; opt.textContent = `${d.name} (${fmt(d.price)})`;
    orderDishSelect.appendChild(opt);
  });
}

function renderOrder(){
  orderList.innerHTML = "";
  let tot = 0;
  order.forEach((it, idx) => {
    const li = document.createElement('li');
    const left = document.createElement('div');
    left.style.flex = "1";
    const row1 = `${it.qty} x ${it.name} — ${fmt(it.price * it.qty)}`;
    const row2 = it.note ? `<div><small>Note: ${it.note}</small></div>` : "";
    left.innerHTML = `<div>${row1}</div>${row2}`;
    const right = document.createElement('div');
    right.innerHTML = `<div class="row"><button data-minus="${idx}">-</button><button data-plus="${idx}">+</button><button class="danger" data-rem="${idx}">Rimuovi</button></div>`;
    li.appendChild(left); li.appendChild(right);
    orderList.appendChild(li);
    tot += it.price * it.qty;
  });
  orderTotal.textContent = fmt(tot);
}

function renderReceipt(){
  const now = new Date();
  let html = `<div style="text-align:center;font-weight:700">Pizza Gegé</div>`;
  html += `<div style="text-align:center"><small>${now.toLocaleString()}</small></div>`;
  html += `<hr>`;
  let tot = 0;
  order.forEach(it => {
    html += `<div>${it.qty} x ${it.name} <span style="float:right">${fmt(it.price * it.qty)}</span></div>`;
    if (it.note) html += `<div><small>Note: ${it.note}</small></div>`;
    tot += it.price * it.qty;
  });
  html += `<hr><div><strong>Totale</strong> <span style="float:right"><strong>${fmt(tot)}</strong></span></div>`;
  receiptArea.innerHTML = html;
}

// Listeners
searchInput.addEventListener('input', renderPublic);

saveDish.addEventListener('click', () => {
  const name = dishName.value.trim();
  const price = parseFloat(dishPrice.value.replace(',', '.')) || 0;
  const description = dishDesc.value.trim();
  if (!name || price<=0){ alert("Nome e prezzo validi necessari"); return; }
  if (editingId !== null){
    menu[editingId] = { ...menu[editingId], name, price, description };
    editingId = null;
  } else {
    menu.push({ id: crypto.randomUUID(), name, price, description });
  }
  dishName.value = ""; dishPrice.value = ""; dishDesc.value = "";
  saveMenu();
});

clearForm.addEventListener('click', () => { editingId = null; dishName.value=""; dishPrice.value=""; dishDesc.value=""; });

adminMenuList.addEventListener('click', (e) => {
  const del = e.target.getAttribute('data-del');
  const edit = e.target.getAttribute('data-edit');
  if (del !== null){
    if (confirm("Eliminare il piatto?")) { menu.splice(parseInt(del),1); saveMenu(); }
  } else if (edit !== null){
    const d = menu[parseInt(edit)];
    dishName.value = d.name; dishPrice.value = String(d.price).replace('.', ','); dishDesc.value = d.description||"";
    editingId = parseInt(edit);
  }
});

addToOrderBtn.addEventListener('click', () => {
  const idx = parseInt(orderDishSelect.value);
  if (isNaN(idx) || !menu[idx]) { alert("Seleziona un piatto"); return; }
  const qty = Math.max(1, parseInt(orderQty.value)||1);
  const note = orderNote.value.trim();
  const d = menu[idx];
  const existing = order.findIndex(x => x.name===d.name && (x.note||"") === note);
  if (existing>=0){
    order[existing].qty += qty;
  } else {
    order.push({ name: d.name, price: d.price, qty, note });
  }
  orderNote.value = "";
  orderQty.value = 1;
  saveOrder();
});

orderList.addEventListener('click', (e) => {
  const plus = e.target.getAttribute('data-plus');
  const minus = e.target.getAttribute('data-minus');
  const rem = e.target.getAttribute('data-rem');
  if (plus !== null){ order[parseInt(plus)].qty++; saveOrder(); }
  else if (minus !== null){ const i=parseInt(minus); order[i].qty=Math.max(1, order[i].qty-1); saveOrder(); }
  else if (rem !== null){ order.splice(parseInt(rem),1); saveOrder(); }
});

printBtn.addEventListener('click', () => {
  const win = window.open('', 'PRINT', 'height=600,width=400');
  win.document.write('<html><head><title>Scontrino</title>');
  win.document.write('<style>body{font-family: -apple-system, Arial; padding:12px;} hr{border:none;border-top:1px dashed #999}</style>');
  win.document.write('</head><body>');
  win.document.write(receiptArea.innerHTML);
  win.document.write('</body></html>');
  win.document.close();
  win.focus();
  win.print();
  setTimeout(()=>win.close(), 500);
});

clearOrderBtn.addEventListener('click', () => {
  if (confirm("Svuotare la comanda?")) { order = []; saveOrder(); }
});

// Tabs
document.querySelector('.tabs').addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
  e.target.classList.add('active');
  const t = e.target.dataset.tab;
  document.querySelectorAll('.tab').forEach(div => div.classList.remove('active'));
  document.getElementById('tab-'+t).classList.add('active');
});

// PIN modal
lockBtn.addEventListener('click', () => {
  pinModal.classList.remove('hidden');
  pinInput.value = "";
  setTimeout(()=>pinInput.focus(), 50);
});
pinCancel.addEventListener('click', () => pinModal.classList.add('hidden'));
pinOk.addEventListener('click', () => {
  if (pinInput.value === config.pin){
    pinModal.classList.add('hidden');
    publicView.classList.add('hidden');
    internalView.classList.remove('hidden');
    renderAdmin(); renderDishSelect(); renderOrder(); renderReceipt();
  } else {
    alert("PIN errato");
  }
});

// Initial demo data if empty
if (menu.length === 0){
  menu = [
    { id: crypto.randomUUID(), name: "Tagliere Sudri km0", price: 15.00, description: "Affettati Sudri, formaggi, verdure sott’olio, pizza bianca" },
    { id: crypto.randomUUID(), name: "Margherita", price: 6.00, description: "Pomodoro, fiordilatte" },
    { id: crypto.randomUUID(), name: "Diavola", price: 7.00, description: "Salame piccante" }
  ];
  saveMenu();
} else {
  renderPublic();
}
renderPublic();
renderDishSelect();
renderOrder();
renderReceipt();
