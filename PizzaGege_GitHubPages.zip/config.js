window.PIZZA_GEGE_CONFIG = {
  pin: "1234",              // PIN per area interna
  currency: "€",
  brand: {
    name: "Pizza Gegé",
    primary: "#5B2E8A",
    accent: "#F2E6D8"
  }
};